package studio.onknight.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.graphics.drawable.GradientDrawable;
import android.net.TrafficStats;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.text.InputType;
import android.widget.BaseAdapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    // ---------- EDIT THESE ----------
    // Fallback used only if the automatic lookup fails and nothing is saved yet.
    static final String DEFAULT_CITY = "Burlington";
    static final double DEFAULT_LAT = 43.3255, DEFAULT_LON = -79.7990;
    static final String DEFAULT_COUNTRY = "CA";
    // Countries that use Fahrenheit for everyday weather.
    static final String[] FAHRENHEIT_COUNTRIES = {"US", "PR", "GU", "VI", "AS", "MP", "BS", "BZ", "KY", "LR", "PW", "FM", "MH"};
    // App names shown in the bottom row, in order. Matches the app's label on the TV.
    static final String[] FAVOURITES = {"TiviMate", "TV", "SmartTube", "Moonfin", "Jellyfin", "NostalgiaTV", "Symfonium"};
    // --------------------------------

    static class App { String label, pkg, cls; ResolveInfo ri; }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private PackageManager pm;
    private List<App> allApps = new ArrayList<>();
    private TextView tempView, weatherView, statsView;
    private GridView grid;
    private View firstTile;
    private long lastRx, lastTx, lastT;

    // ---------- v0.2 wallpaper ----------
    static final String PREFS = "onknight";
    static final String KEY_SETUP_DONE = "setup_done";
    static final String WALLPAPER_FILE = "wallpaper.jpg";
    static final int REQ_PERM = 43;
    static final int MAX_EDGE = 1920; // longest side after scaling
    static final String KEY_CITY = "loc_city", KEY_LAT = "loc_lat", KEY_LON = "loc_lon",
            KEY_COUNTRY = "loc_country", KEY_UNIT = "unit", KEY_LOC_MANUAL = "loc_manual";
    private String city = DEFAULT_CITY, country = DEFAULT_COUNTRY;
    private double lat = DEFAULT_LAT, lon = DEFAULT_LON;
    private boolean fahrenheit = false;
    private ImageView bg;
    // v0.4 weather icons
    private WeatherIcon bigIcon;
    private final WeatherIcon[] dayIcons = new WeatherIcon[5];
    private final TextView[] dayNames = new TextView[5];
    private final TextView[] dayTemps = new TextView[5];
    // v0.4 folder browser
    private final List<File> browseList = new ArrayList<>();
    private final List<String> browseNames = new ArrayList<>();
    private File browseDir; // null means the storage list
    private ArrayAdapter<String> browseAdapter;
    private ListView browseLv;
    private TextView browsePath;
    private AlertDialog browser;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pm = getPackageManager();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadLocation();
        loadApps();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        loadWallpaper();
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        // Left panel: weather (icon + 5 day forecast) + system stats
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setPadding(dp(22), dp(16), dp(22), dp(16));
        left.setBackground(panel(0x99000000));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        bigIcon = new WeatherIcon(this);
        head.addView(bigIcon, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout headText = new LinearLayout(this);
        headText.setOrientation(LinearLayout.VERTICAL);
        tempView = text(30, true, Color.WHITE);
        weatherView = text(15, false, Color.WHITE);
        tempView.setText("--\u00B0");
        weatherView.setText(city);
        headText.addView(tempView);
        headText.addView(weatherView);
        LinearLayout.LayoutParams htp = new LinearLayout.LayoutParams(-2, -2);
        htp.leftMargin = dp(14);
        head.addView(headText, htp);
        left.addView(head);

        LinearLayout forecastRow = new LinearLayout(this);
        forecastRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(12);
        left.addView(forecastRow, fp);
        for (int i = 0; i < 5; i++) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            dayNames[i] = text(13, false, 0xFFB9D7FF);
            dayIcons[i] = new WeatherIcon(this);
            dayTemps[i] = text(13, false, Color.WHITE);
            cell.addView(dayNames[i]);
            cell.addView(dayIcons[i], new LinearLayout.LayoutParams(dp(36), dp(36)));
            cell.addView(dayTemps[i]);
            forecastRow.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }

        statsView = text(15, false, 0xFFB9D7FF);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = dp(14);
        left.addView(statsView, sp);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(470), -2, Gravity.TOP | Gravity.START);
        lp.setMargins(dp(40), dp(30), 0, 0);
        root.addView(left, lp);

        // Right: clock + date
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        right.setPadding(dp(22), dp(10), dp(22), dp(10));
        right.setBackground(panel(0x66000000));
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm a");
        clock.setFormat24Hour("h:mm a");
        clock.setTextSize(48);
        clock.setTypeface(null, android.graphics.Typeface.BOLD);
        clock.setTextColor(0xFFB44CFF);
        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEE, MMM d");
        date.setFormat24Hour("EEE, MMM d");
        date.setTextSize(22);
        date.setTextColor(Color.WHITE);
        right.addView(clock);
        right.addView(date);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        rp.setMargins(0, dp(30), dp(40), 0);
        root.addView(right, rp);

        // Bottom: favourites row
        HorizontalScrollView sv = new HorizontalScrollView(this);
        sv.setHorizontalScrollBarEnabled(false);
        sv.setClipChildren(false);
        sv.setClipToPadding(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        row.setPadding(dp(40), dp(24), dp(40), dp(64));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.rightMargin = dp(14);
        for (final App a : pickFavourites()) {
            View t = tile(a.label, a.ri.loadIcon(pm), v -> launch(a));
            if (firstTile == null) firstTile = t;
            row.addView(t, tp);
        }
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(0xFF7B3FE4);
        View allTile = tile("All apps", dot, v -> showGrid());
        if (firstTile == null) firstTile = allTile;
        row.addView(allTile, tp);
        GradientDrawable wpDot = new GradientDrawable();
        wpDot.setShape(GradientDrawable.OVAL);
        wpDot.setColor(0xFF2A8AE4);
        row.addView(tile("Settings", wpDot, v -> showSettingsMenu()), tp);
        sv.addView(row);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(sv, bp);

        // All-apps overlay
        grid = new GridView(this);
        grid.setNumColumns(6);
        grid.setVerticalSpacing(dp(12));
        grid.setHorizontalSpacing(dp(12));
        grid.setBackgroundColor(0xEE000000);
        grid.setPadding(dp(60), dp(50), dp(60), dp(50));
        grid.setSelector(panel(0x663A2A7A));
        grid.setVisibility(View.GONE);
        grid.setAdapter(new BaseAdapter() {
            public int getCount() { return allApps.size(); }
            public Object getItem(int i) { return allApps.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int pos, View cv, ViewGroup parent) {
                LinearLayout t;
                ImageView iv;
                TextView tv;
                if (cv == null) {
                    t = new LinearLayout(MainActivity.this);
                    t.setOrientation(LinearLayout.VERTICAL);
                    t.setGravity(Gravity.CENTER);
                    t.setPadding(dp(8), dp(10), dp(8), dp(10));
                    iv = new ImageView(MainActivity.this);
                    t.addView(iv, new LinearLayout.LayoutParams(dp(72), dp(72)));
                    tv = text(14, false, Color.WHITE);
                    tv.setSingleLine(true);
                    tv.setGravity(Gravity.CENTER);
                    t.addView(tv, new LinearLayout.LayoutParams(-2, -2));
                } else {
                    t = (LinearLayout) cv;
                    iv = (ImageView) t.getChildAt(0);
                    tv = (TextView) t.getChildAt(1);
                }
                App a = allApps.get(pos);
                iv.setImageDrawable(a.ri.loadIcon(pm));
                tv.setText(a.label);
                return t;
            }
        });
        grid.setOnItemClickListener((p, v, pos, id) -> launch(allApps.get(pos)));
        root.addView(grid, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        if (firstTile != null) firstTile.requestFocus();
        if (!prefs.contains(KEY_CITY) && !prefs.getBoolean(KEY_LOC_MANUAL, false)) detectLocation(false);
        if (!prefs.getBoolean(KEY_SETUP_DONE, false)) root.post(this::showFirstRunPrompt);
    }

    @Override protected void onResume() {
        super.onResume();
        ui.post(weatherTask);
        ui.post(statsTask);
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacksAndMessages(null);
    }

    @Override public void onBackPressed() {
        if (grid.getVisibility() == View.VISIBLE) {
            grid.setVisibility(View.GONE);
            if (firstTile != null) firstTile.requestFocus();
        } // Home screen: do nothing
    }



    // ---------- v0.3 location + units ----------
    private void loadLocation() {
        city = prefs.getString(KEY_CITY, DEFAULT_CITY);
        country = prefs.getString(KEY_COUNTRY, DEFAULT_COUNTRY);
        lat = Double.longBitsToDouble(prefs.getLong(KEY_LAT, Double.doubleToLongBits(DEFAULT_LAT)));
        lon = Double.longBitsToDouble(prefs.getLong(KEY_LON, Double.doubleToLongBits(DEFAULT_LON)));
        String u = prefs.getString(KEY_UNIT, null);
        fahrenheit = u != null ? u.equals("F") : usesFahrenheit(country);
    }

    private static boolean usesFahrenheit(String cc) {
        if (cc == null) return false;
        for (String c : FAHRENHEIT_COUNTRIES) if (c.equalsIgnoreCase(cc)) return true;
        return false;
    }

    private void saveLocation(String c, double la, double lo, String cc, boolean manual) {
        city = c; lat = la; lon = lo; country = cc;
        SharedPreferences.Editor e = prefs.edit();
        e.putString(KEY_CITY, c).putString(KEY_COUNTRY, cc)
                .putLong(KEY_LAT, Double.doubleToLongBits(la))
                .putLong(KEY_LON, Double.doubleToLongBits(lo))
                .putBoolean(KEY_LOC_MANUAL, manual);
        e.apply();
        // Unit follows the country unless the user has picked one by hand in Settings.
        if (!prefs.contains(KEY_UNIT)) fahrenheit = usesFahrenheit(cc);
    }

    private static String httpGet(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "OnknightLauncher/0.3");
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = r.readLine()) != null) sb.append(ln);
        r.close();
        c.disconnect();
        return sb.toString();
    }

    /** Rough location from the TV's internet connection (no permission needed). */
    private void detectLocation(final boolean announce) {
        new Thread(() -> {
            try {
                JSONObject j = new JSONObject(httpGet("https://ipapi.co/json/"));
                if (j.has("error") || !j.has("latitude")) throw new Exception("lookup failed");
                final String c = j.optString("city", DEFAULT_CITY);
                final String cc = j.optString("country_code", DEFAULT_COUNTRY);
                final double la = j.getDouble("latitude"), lo = j.getDouble("longitude");
                ui.post(() -> {
                    saveLocation(c, la, lo, cc, false);
                    weatherView.setText(city);
                    fetchWeather();
                    if (announce) Toast.makeText(this, "Location set to " + c, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (announce) Toast.makeText(this, "Couldn't detect location. Use Set my city.", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    /** Manual override: type a city name, look it up with Open-Meteo's search. */
    private void askCity() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("City name, e.g. Leeds or Dallas");
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("Set my city")
                .setView(input)
                .setPositiveButton("Search", (d, w) -> lookupCity(input.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void lookupCity(final String name) {
        if (name.isEmpty()) return;
        new Thread(() -> {
            try {
                String u = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&name=" + URLEncoder.encode(name, "UTF-8");
                JSONObject j = new JSONObject(httpGet(u));
                if (!j.has("results")) {
                    ui.post(() -> Toast.makeText(this, "No match for " + name, Toast.LENGTH_LONG).show());
                    return;
                }
                JSONObject r = j.getJSONArray("results").getJSONObject(0);
                final String c = r.optString("name", name);
                final String cc = r.optString("country_code", "");
                final double la = r.getDouble("latitude"), lo = r.getDouble("longitude");
                ui.post(() -> {
                    saveLocation(c, la, lo, cc, true);
                    weatherView.setText(city);
                    fetchWeather();
                    Toast.makeText(this, "Location set to " + c, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                ui.post(() -> Toast.makeText(this, "Search failed. Check the internet connection.", Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    // ---------- v0.2 wallpaper picker ----------
    /** Shows the user's saved wallpaper if there is one, otherwise the built-in default. */
    private void loadWallpaper() {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.RGB_565; // half the RAM of a normal bitmap
        File f = new File(getFilesDir(), WALLPAPER_FILE);
        Bitmap bmp = null;
        if (f.exists()) bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        if (bmp == null) bmp = BitmapFactory.decodeResource(getResources(), R.drawable.wallpaper, o);
        bg.setImageBitmap(bmp);
    }

    /** First launch only: default wallpaper or pick your own. */
    private void showFirstRunPrompt() {
        new AlertDialog.Builder(this)
                .setTitle("Welcome to Onknight Launcher")
                .setMessage("Use the default wallpaper, or pick one of your own?\n\n"
                        + "Tip: if the Home button keeps opening the stock screen, a tool like TVBoxTools "
                        + "can lock this launcher in as your default.")
                .setCancelable(false)
                .setPositiveButton("Use default", (d, w) -> prefs.edit().putBoolean(KEY_SETUP_DONE, true).apply())
                .setNegativeButton("Choose my own", (d, w) -> {
                    prefs.edit().putBoolean(KEY_SETUP_DONE, true).apply();
                    pickWallpaper();
                })
                .show();
    }

    /** Settings tile menu. */
    private void showSettingsMenu() {
        String unitLabel = fahrenheit ? "Temperature: switch to Celsius" : "Temperature: switch to Fahrenheit";
        new AlertDialog.Builder(this)
                .setTitle("Settings")
                .setItems(new String[]{"Wallpaper: choose my own", "Wallpaper: reset to default",
                        "Set my city", "Detect my location again", unitLabel}, (d, which) -> {
                    switch (which) {
                        case 0: pickWallpaper(); break;
                        case 1: resetWallpaper(); break;
                        case 2: askCity(); break;
                        case 3: prefs.edit().putBoolean(KEY_LOC_MANUAL, false).apply(); detectLocation(true); break;
                        case 4:
                            fahrenheit = !fahrenheit;
                            prefs.edit().putString(KEY_UNIT, fahrenheit ? "F" : "C").apply();
                            fetchWeather();
                            break;
                    }
                })
                .show();
    }

    // ---------- v0.4 built-in folder browser ----------
    /** Asks for storage access if needed, then opens the browser. */
    private void pickWallpaper() {
        String perm = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) openBrowser();
        else requestPermissions(new String[]{perm}, REQ_PERM);
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req != REQ_PERM) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) openBrowser();
        else Toast.makeText(this, "Storage permission is needed to browse for a wallpaper", Toast.LENGTH_LONG).show();
    }

    private void openBrowser() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xFF12161F);
        box.setPadding(dp(16), dp(10), dp(16), dp(10));
        browsePath = text(14, false, 0xFF9AA7B8);
        browsePath.setSingleLine(true);
        box.addView(browsePath);

        browseAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, browseNames) {
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                TextView tv = (TextView) super.getView(pos, cv, parent);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(18);
                tv.setSingleLine(true);
                return tv;
            }
        };
        browseLv = new ListView(this);
        browseLv.setAdapter(browseAdapter);
        browseLv.setSelector(panel(0x883A2A7A));
        browseLv.setOnItemClickListener((p, v, pos, id) -> onBrowseClick(pos));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(380));
        lp.topMargin = dp(8);
        box.addView(browseLv, lp);

        browser = new AlertDialog.Builder(this)
                .setTitle("Choose a wallpaper")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .create();
        // Back goes up one folder; at the storage list it closes the browser.
        browser.setOnKeyListener((d, key, ev) -> {
            if (key == KeyEvent.KEYCODE_BACK && ev.getAction() == KeyEvent.ACTION_UP && browseDir != null) {
                browseUp();
                return true;
            }
            return false;
        });
        List<File> roots = storageRoots();
        showDir(roots.size() == 1 ? roots.get(0) : null);
        browser.show();
    }

    /** Internal storage plus any USB drive or SD card. */
    private List<File> storageRoots() {
        List<File> out = new ArrayList<>();
        File prim = Environment.getExternalStorageDirectory();
        if (prim != null) out.add(prim);
        File[] dirs = getExternalFilesDirs(null);
        if (dirs != null) {
            for (File d : dirs) {
                if (d == null) continue;
                String path = d.getAbsolutePath();
                int i = path.indexOf("/Android/data");
                if (i > 0) {
                    File r = new File(path.substring(0, i));
                    if (!out.contains(r)) out.add(r);
                }
            }
        }
        File[] st = new File("/storage").listFiles();
        if (st != null) {
            for (File s : st) {
                String n = s.getName();
                if (n.equals("self") || n.equals("emulated")) continue;
                if (s.isDirectory() && s.canRead() && !out.contains(s)) out.add(s);
            }
        }
        return out;
    }

    private String rootLabel(File r) {
        if (r.equals(Environment.getExternalStorageDirectory())) return "Internal storage";
        return "USB drive / SD card  (" + r.getName() + ")";
    }

    private static boolean isImage(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp") || n.endsWith(".bmp");
    }

    /** Lists one folder (folders first, then pictures). null shows the storage list. */
    private void showDir(File dir) {
        browseDir = dir;
        browseList.clear();
        browseNames.clear();
        if (dir == null) {
            browsePath.setText("Choose a storage location");
            for (File r : storageRoots()) {
                browseList.add(r);
                browseNames.add("\u25B8  " + rootLabel(r));
            }
            if (browseList.isEmpty()) browseNames.add("No storage found");
        } else {
            browsePath.setText(dir.getAbsolutePath());
            browseList.add(null);
            browseNames.add("\u2191  Up");
            List<File> dirs = new ArrayList<>(), imgs = new ArrayList<>();
            File[] kids = dir.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    if (k.getName().startsWith(".")) continue;
                    if (k.isDirectory()) dirs.add(k);
                    else if (isImage(k.getName())) imgs.add(k);
                }
            }
            Collections.sort(dirs, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            Collections.sort(imgs, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            for (File d : dirs) {
                browseList.add(d);
                browseNames.add("\u25B8  " + d.getName());
            }
            for (File f : imgs) {
                browseList.add(f);
                browseNames.add(f.getName() + "   (" + (f.length() / 1024) + " KB)");
            }
            if (dirs.isEmpty() && imgs.isEmpty()) browseNames.add("(no pictures or folders here)");
        }
        browseAdapter.notifyDataSetChanged();
        browseLv.setSelection(0);
        browseLv.requestFocus();
    }

    private void browseUp() {
        if (browseDir == null) return;
        for (File r : storageRoots()) {
            if (r.equals(browseDir)) { showDir(null); return; }
        }
        showDir(browseDir.getParentFile());
    }

    private void onBrowseClick(int pos) {
        if (pos >= browseList.size()) return; // placeholder rows
        File f = browseList.get(pos);
        if (f == null) browseUp();
        else if (f.isDirectory()) showDir(f);
        else {
            browser.dismiss();
            applyWallpaperFile(f);
        }
    }

    private void applyWallpaperFile(final File f) {
        Toast.makeText(this, "Setting wallpaper...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean ok = saveScaled(Uri.fromFile(f));
            ui.post(() -> {
                if (ok) loadWallpaper();
                Toast.makeText(this, ok ? "Wallpaper updated" : "Couldn't use that image", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    /** Decodes the picked image at reduced size and stores a compressed copy, to save RAM and storage. */
    private boolean saveScaled(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false;
            int sample = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_EDGE) sample *= 2;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bmp;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(in, null, o);
            }
            if (bmp == null) return false;
            int longest = Math.max(bmp.getWidth(), bmp.getHeight());
            if (longest > MAX_EDGE) {
                float s = MAX_EDGE / (float) longest;
                Bitmap scaled = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * s), Math.round(bmp.getHeight() * s), true);
                if (scaled != bmp) bmp.recycle();
                bmp = scaled;
            }
            File out = new File(getFilesDir(), WALLPAPER_FILE);
            try (FileOutputStream fos = new FileOutputStream(out)) {
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, fos);
            }
            bmp.recycle();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void resetWallpaper() {
        File f = new File(getFilesDir(), WALLPAPER_FILE);
        if (f.exists()) f.delete();
        loadWallpaper();
        Toast.makeText(this, "Default wallpaper restored", Toast.LENGTH_SHORT).show();
    }

    private void showGrid() {
        grid.setVisibility(View.VISIBLE);
        grid.requestFocus();
    }

    // ---------- apps ----------
    private void loadApps() {
        Map<String, App> map = new LinkedHashMap<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || map.containsKey(p)) continue;
                App a = new App();
                a.label = String.valueOf(ri.loadLabel(pm));
                a.pkg = p;
                a.cls = ri.activityInfo.name;
                a.ri = ri;
                map.put(p, a);
            }
        }
        allApps = new ArrayList<>(map.values());
        Collections.sort(allApps, (x, y) -> x.label.compareToIgnoreCase(y.label));
    }

    private List<App> pickFavourites() {
        List<App> out = new ArrayList<>();
        for (String k : FAVOURITES) {
            App hit = null;
            for (App a : allApps)
                if (a.label.equalsIgnoreCase(k) && !out.contains(a)) { hit = a; break; }
            if (hit == null && k.length() > 3)
                for (App a : allApps)
                    if (a.label.toLowerCase(Locale.ROOT).contains(k.toLowerCase(Locale.ROOT)) && !out.contains(a)) { hit = a; break; }
            if (hit != null) out.add(hit);
        }
        return out;
    }

    private void launch(App a) {
        try {
            startActivity(new Intent(Intent.ACTION_MAIN).setClassName(a.pkg, a.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Toast.makeText(this, "Can't open " + a.label, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- UI helpers ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private Drawable panel(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(18));
        return g;
    }

    private TextView text(int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private View tile(String label, Drawable icon, View.OnClickListener click) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(18), dp(14), dp(18), dp(12));
        t.setBackground(panel(0xAA000000));
        t.setFocusable(true);
        t.setClickable(true);
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        t.addView(iv, new LinearLayout.LayoutParams(dp(72), dp(72)));
        TextView tv = text(14, false, Color.WHITE);
        tv.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(6);
        t.addView(tv, lp);
        tv.setText(label);
        t.setOnClickListener(click);
        t.setOnFocusChangeListener((v, f) -> {
            v.animate().scaleX(f ? 1.12f : 1f).scaleY(f ? 1.12f : 1f).setDuration(120).start();
            v.setBackground(panel(f ? 0xFF3A2A7A : 0xAA000000));
        });
        return t;
    }

    // ---------- system stats ----------
    private final Runnable statsTask = new Runnable() {
        public void run() { updateStats(); ui.postDelayed(this, 2000); }
    };

    private void updateStats() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double tot = mi.totalMem / 1073741824.0, used = (mi.totalMem - mi.availMem) / 1073741824.0;
        long freeMb = new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes() / 1048576;
        String storage = freeMb >= 1024 ? String.format(Locale.US, "%.1f GB", freeMb / 1024.0) : freeMb + " MB";
        String net = "";
        long now = System.currentTimeMillis(), rx = TrafficStats.getTotalRxBytes(), tx = TrafficStats.getTotalTxBytes();
        if (lastT > 0 && now > lastT && rx != TrafficStats.UNSUPPORTED) {
            double dt = (now - lastT) / 1000.0;
            net = String.format(Locale.US, "\n\u2193 %d KB/s   \u2191 %d KB/s", (long) ((rx - lastRx) / 1024 / dt), (long) ((tx - lastTx) / 1024 / dt));
        }
        lastT = now; lastRx = rx; lastTx = tx;
        statsView.setText(String.format(Locale.US, "Memory  %.1f / %.1f GB\nStorage  %s free", used, tot, storage) + net);
    }

    // ---------- weather (Open-Meteo, no API key) ----------
    private final Runnable weatherTask = new Runnable() {
        public void run() { fetchWeather(); ui.postDelayed(this, 30 * 60 * 1000L); }
    };

    private static String wx(int c) {
        if (c == 0) return "Clear";
        if (c <= 2) return "Partly cloudy";
        if (c == 3) return "Cloudy";
        if (c == 45 || c == 48) return "Fog";
        if (c >= 51 && c <= 57) return "Drizzle";
        if (c >= 61 && c <= 67) return "Rain";
        if (c >= 71 && c <= 77) return "Snow";
        if (c >= 80 && c <= 82) return "Showers";
        if (c == 85 || c == 86) return "Snow showers";
        if (c >= 95) return "Thunderstorm";
        return "Cloudy";
    }

    private void fetchWeather() {
        final double la = lat, lo = lon;
        final String cityName = city;
        final boolean f = fahrenheit;
        new Thread(() -> {
            try {
                String u = "https://api.open-meteo.com/v1/forecast?latitude=" + la + "&longitude=" + lo
                        + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5"
                        + (f ? "&temperature_unit=fahrenheit&wind_speed_unit=mph" : "");
                JSONObject j = new JSONObject(httpGet(u));
                JSONObject cur = j.getJSONObject("current");
                final int curCode = cur.getInt("weather_code");
                final String temp = Math.round(cur.getDouble("temperature_2m")) + "\u00B0  " + wx(curCode);
                final String info = cityName + "\nFeels " + Math.round(cur.getDouble("apparent_temperature")) + "\u00B0  \u2022  "
                        + Math.round(cur.getDouble("relative_humidity_2m")) + "%  \u2022  "
                        + Math.round(cur.getDouble("wind_speed_10m")) + (f ? " mph" : " km/h");
                JSONObject dl = j.getJSONObject("daily");
                JSONArray t = dl.getJSONArray("time"), hi = dl.getJSONArray("temperature_2m_max"),
                        lo2 = dl.getJSONArray("temperature_2m_min"), wc = dl.getJSONArray("weather_code");
                SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                SimpleDateFormat out = new SimpleDateFormat("EEE", Locale.getDefault());
                final int n = Math.min(5, t.length());
                final String[] names = new String[n], temps = new String[n];
                final int[] codes = new int[n];
                for (int i = 0; i < n; i++) {
                    names[i] = i == 0 ? "Today" : out.format(in.parse(t.getString(i)));
                    temps[i] = Math.round(hi.getDouble(i)) + "\u00B0/" + Math.round(lo2.getDouble(i)) + "\u00B0";
                    codes[i] = wc.getInt(i);
                }
                ui.post(() -> {
                    tempView.setText(temp);
                    weatherView.setText(info);
                    bigIcon.setCode(curCode);
                    for (int k = 0; k < 5; k++) {
                        boolean has = k < n;
                        dayNames[k].setText(has ? names[k] : "");
                        dayTemps[k].setText(has ? temps[k] : "");
                        dayIcons[k].setCode(has ? codes[k] : -1);
                    }
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (tempView.getText().toString().startsWith("--")) weatherView.setText(cityName + "\nWeather unavailable");
                });
            }
        }).start();
    }

    // ---------- v0.4 weather icons (drawn in code, no image files) ----------
    static class WeatherIcon extends View {
        private int code = -1;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF rect = new RectF();

        WeatherIcon(android.content.Context c) { super(c); }

        void setCode(int c) { code = c; invalidate(); }

        static int kind(int c) {
            if (c == 0) return 0;                                   // clear
            if (c <= 2) return 1;                                   // partly cloudy
            if (c == 3) return 2;                                   // cloudy
            if (c == 45 || c == 48) return 3;                       // fog
            if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return 4; // drizzle / rain / showers
            if ((c >= 71 && c <= 77) || c == 85 || c == 86) return 5;    // snow
            if (c >= 95) return 6;                                  // thunderstorm
            return 2;
        }

        @Override protected void onDraw(Canvas cv) {
            if (code < 0) return;
            float s = Math.min(getWidth(), getHeight());
            cv.save();
            cv.translate((getWidth() - s) / 2f, (getHeight() - s) / 2f);
            switch (kind(code)) {
                case 0:
                    sun(cv, s * 0.5f, s * 0.5f, s * 0.22f);
                    break;
                case 1:
                    sun(cv, s * 0.36f, s * 0.34f, s * 0.15f);
                    cloud(cv, s * 0.56f, s * 0.58f, s * 0.78f, 0xFFE8EEF7);
                    break;
                case 2:
                    cloud(cv, s * 0.5f, s * 0.5f, s * 0.84f, 0xFFC9D3E0);
                    break;
                case 3:
                    cloud(cv, s * 0.5f, s * 0.38f, s * 0.8f, 0xFFB5C2D3);
                    stroke(0xFF9FB0C6, s * 0.06f);
                    cv.drawLine(s * 0.25f, s * 0.68f, s * 0.75f, s * 0.68f, p);
                    cv.drawLine(s * 0.32f, s * 0.82f, s * 0.68f, s * 0.82f, p);
                    break;
                case 4:
                    cloud(cv, s * 0.5f, s * 0.36f, s * 0.8f, 0xFFB5C2D3);
                    stroke(0xFF4FB3FF, s * 0.06f);
                    for (float x : new float[]{0.32f, 0.5f, 0.68f})
                        cv.drawLine(x * s, 0.6f * s, (x - 0.06f) * s, 0.82f * s, p);
                    break;
                case 5:
                    cloud(cv, s * 0.5f, s * 0.36f, s * 0.8f, 0xFFD5DEEA);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Color.WHITE);
                    cv.drawCircle(s * 0.32f, s * 0.68f, s * 0.045f, p);
                    cv.drawCircle(s * 0.5f, s * 0.82f, s * 0.045f, p);
                    cv.drawCircle(s * 0.68f, s * 0.68f, s * 0.045f, p);
                    break;
                default:
                    cloud(cv, s * 0.5f, s * 0.36f, s * 0.8f, 0xFF8E9BB0);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFFFD43B);
                    path.reset();
                    path.moveTo(s * 0.54f, s * 0.58f);
                    path.lineTo(s * 0.40f, s * 0.80f);
                    path.lineTo(s * 0.50f, s * 0.80f);
                    path.lineTo(s * 0.44f, s * 0.96f);
                    path.lineTo(s * 0.64f, s * 0.70f);
                    path.lineTo(s * 0.53f, s * 0.70f);
                    path.lineTo(s * 0.60f, s * 0.58f);
                    path.close();
                    cv.drawPath(path, p);
                    break;
            }
            cv.restore();
        }

        private void stroke(int color, float width) {
            p.setStyle(Paint.Style.STROKE);
            p.setColor(color);
            p.setStrokeWidth(width);
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        private void sun(Canvas cv, float cx, float cy, float r) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFC83D);
            cv.drawCircle(cx, cy, r, p);
            stroke(0xFFFFC83D, r * 0.28f);
            for (int i = 0; i < 8; i++) {
                double a = Math.PI / 4 * i;
                float c = (float) Math.cos(a), sn = (float) Math.sin(a);
                cv.drawLine(cx + c * r * 1.45f, cy + sn * r * 1.45f, cx + c * r * 1.9f, cy + sn * r * 1.9f, p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        private void cloud(Canvas cv, float cx, float cy, float w, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            float r = w * 0.2f;
            cv.drawCircle(cx - w * 0.22f, cy, r, p);
            cv.drawCircle(cx + w * 0.02f, cy - r * 0.55f, r * 1.25f, p);
            cv.drawCircle(cx + w * 0.26f, cy + r * 0.05f, r * 0.9f, p);
            rect.set(cx - w * 0.42f, cy, cx + w * 0.44f, cy + r);
            cv.drawRoundRect(rect, r * 0.5f, r * 0.5f, p);
        }
    }
}
